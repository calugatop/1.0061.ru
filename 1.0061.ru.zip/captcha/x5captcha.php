<?php
include("../res/x5engine.php");
$nameList = array("xz4","8vj","c3c","lw2","ema","ldx","ndd","yy8","fu4","zn2");
$charList = array("G","E","S","W","5","2","N","7","V","F");
$cpt = new X5Captcha($nameList, $charList);
//Check Captcha
if ($_GET["action"] == "check")
	echo $cpt->check($_GET["code"], $_GET["ans"]);
//Show Captcha chars
else if ($_GET["action"] == "show")
	echo $cpt->show($_GET['code']);
// End of file x5captcha.php
