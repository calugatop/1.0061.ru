<?php
	$oNameList = array("nu4","p5y","slj","zlc","6vj","wcd","gjk","zxw","upc","j7d");
	$oCharList = array("W","N","E","M","8","A","E","C","V","G");
// End of file imkeys.php