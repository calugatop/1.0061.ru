<div class="manager-ads">
	<div class="text-center"><img src="images/wsx5manager_icon.png" alt="WebSite X5 Manager"></div>
	<div class="text-center message"><?php echo l10n("wsx5manager_ads", "A powerful majestic app to manage all your websites from your phone!") ?></div>
	<div class="text-center text-small uppercase fore-color-1"><a href="wsx5-manager.php"><?php echo l10n("wsx5manager_ads_linktext", "Discover the power") ?></a></div>
</div>
