<?php

// Users data
$imSettings['access']['webregistrations_gid'] = '0j2komow';
$imSettings['access']['users'] = array(
	'admin' => array(
		'groups' => array('n1e3bc20'),
		'id' => 'n1e3bc20',
		'name' => 'Admin',
		'password' => 'cc02b6rm',
		'email' => '',
		'page' => 'index.html'
	),
	'новый пользователь' => array(
		'groups' => array('xj2x5vbk'),
		'id' => 'xj2x5vbk',
		'name' => 'Новый пользователь',
		'password' => '487l79t4',
		'email' => '',
		'page' => 'index.html'
	)
);

// Admins list
$imSettings['access']['admins'] = array('n1e3bc20');

// Page/Users permissions
$imSettings['access']['pages'] = array();

// End of file access.inc.php